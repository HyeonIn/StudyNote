package model;

public class BoardTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BoardDao mgr = new BoardDao();
		System.out.println(mgr.deleteOne(4));
	}

}
