package ver1_xml;

public class AdidasShoes implements Shoes{
	@Override
	public String getShoes() {
		// TODO Auto-generated method stub
		return "�Ƶ�ٽ�";
	}
}
