package ver1_xml;

public interface Shoes {
	public String getShoes();
}
