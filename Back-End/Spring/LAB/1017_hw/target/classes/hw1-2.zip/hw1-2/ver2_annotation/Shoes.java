package ver2_annotation;

public interface Shoes {
	public String getShoes();
}
