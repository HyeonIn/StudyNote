package ver2_annotation;

import org.springframework.stereotype.Component;

public class NikeShoes implements Shoes{
	@Override
	public String getShoes() {
		// TODO Auto-generated method stub
		return "����Ű";
	}
}
