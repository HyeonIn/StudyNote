package ver1_xml;

public class NikeShoes implements Shoes{
	@Override
	public String getShoes() {
		// TODO Auto-generated method stub
		return "����Ű";
	}
}
